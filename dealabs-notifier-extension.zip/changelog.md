1.2.9 : 
 - add new theme, laboween
1.2.8 : 
 - add new theme, DealabSkin by oOKaMiZuKOo
1.2.7 : 
 - use imgur to upload images
1.2.6 :
 - add euro 2016 logo (with new theme)
1.2.5 :
 - better error when error with image upload
 - add JVlabs theme
1.2.4 :
 - remove wait text if error when upload image
 - display image loading under the textarea
 - resolve some bugs with selection in textarea
 - don't display notification, if it's your message in forum
1.2.3 :
 - links to home + bugs
1.2.2 :
 - bugs with option link
 1.2.1 :
 - some bugs
 1.2.0 :
 - some bugs
 1.1.18 :
 - easy add an image
 1.1.17 :
 - some bugs
 1.1.16 :
 - some bugs
 1.1.15 :
 - some bugs
 1.1.14 :
 - bug with sound
 1.1.13 :
 - sound with some notifications
 1.1.12 :
 - bug with ignored topics
1.1.11 :
 - refactoring all extension API (for port to FF)
 - add some controls in popup
 - add ctrl key for click in popup (open in background)
1.1.10 :
 - refactoring embed
 - add embed for mojvideo & vimeo
 - change soundclound embed for picture version (maybe not a good idea)
1.1.9 :
 - add blacklist -> repair bugs
 1.1.8 :
 - add blacklist -> need some tests before upload
1.1.7 :
 - mark all read
1.1.6 :
 - text correction
 - add 2 buttons for open profile or open dealabs
1.1.5 :
 - soundcloud api error with https
1.1.4 :
 - add embed for dailymotion and  soundcloud
1.1.2 :
 - add refresh button
1.1.1 :
 - correct bug with smileys
1.1.0 :
 - add themes
1.0.8 :
 - error with settings link
1.0.7 :
 - add setting on context menu
1.0.6 :
 - Bug in settings with lot of smileys